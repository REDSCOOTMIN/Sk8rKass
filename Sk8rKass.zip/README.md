This mod adds a separate custom Kass outfit.

Change into Kass the same way you change between any other character.

This mod requires Crew Boom.

Place the JSON and CBB files into the config then the CrewBoom folder under BepInEx